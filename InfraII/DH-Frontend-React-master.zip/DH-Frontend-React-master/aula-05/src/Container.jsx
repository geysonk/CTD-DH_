function Container({children}){

  return (
    <div style={{background:'black', color:'white'}}>
      {children}
    </div>
  )
}

export default Container;