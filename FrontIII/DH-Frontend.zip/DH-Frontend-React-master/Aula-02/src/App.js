import "./styles.css";

function App() {
  return (
    <>
      <h1 className="title">Hello World</h1>
      <p>Meu Conteudo</p>
      <button onClick={() => alert("ok")}>Pressione</button>
    </>
  );
}

export default App;
