function Text(props){
  return <h1>{props.txt}</h1>
}

export default Text;